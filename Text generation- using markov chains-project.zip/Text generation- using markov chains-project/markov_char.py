import random
from collections import defaultdict

class CharMarkovChain:
    def __init__(self):
        self.model = defaultdict(list)

    def train(self, text):
        for i in range(len(text) - 1):
            self.model[text[i]].append(text[i + 1])

    def generate(self, start_char, length=300):
        if start_char not in self.model:
            return "Start character not found in training data."

        result = [start_char]
        current_char = start_char

        for _ in range(length - 1):
            next_chars = self.model.get(current_char)
            if not next_chars:
                break
            current_char = random.choice(next_chars)
            result.append(current_char)

        return ''.join(result)
