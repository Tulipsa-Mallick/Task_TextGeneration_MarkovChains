from markov_chain import MarkovChain
import re

def load_text(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()

def post_process(text):
    # Capitalize first letter
    text = text[0].upper() + text[1:]
    # Add spacing after punctuation if missing
    text = re.sub(r'([.?!])([A-Za-z])', r'\1 \2', text)
    return text

def format_output(text, width=60):
    return '\n'.join([text[i:i+width] for i in range(0, len(text), width)])

def save_output(text, file_path="generated.txt"):
    with open(file_path, 'a', encoding='utf-8') as f:
        f.write(text + "\n\n")

def main():
    print("🧠 Word-level Markov Chain Text Generator (CLI Edition)\n")

    text = load_text("input.txt")

    mc = MarkovChain()
    mc.train(text)

    while True:
        start = input("Enter a start word (or type 'exit'): ").strip()
        if start.lower() == 'exit':
            print("👋 Goodbye!")
            break

        generated = mc.generate(start_word=start, length=50)
        cleaned = post_process(generated)
        wrapped = format_output(cleaned, width=60)

        print("\n📝 Generated Text:\n")
        print(wrapped)
        print("\n" + "=" * 60)

        save_output(cleaned)

if __name__ == "__main__":
    main()
