import random
from collections import defaultdict

class MarkovChain:
    def __init__(self):
        self.model = defaultdict(list)

    def train(self, text):
        words = text.split()
        for i in range(len(words) - 1):
            self.model[words[i]].append(words[i + 1])

    def generate(self, start_word, length=50):
        if start_word not in self.model:
            return "Start word not found in training data."

        result = [start_word]
        current_word = start_word

        for _ in range(length - 1):
            next_words = self.model.get(current_word)
            if not next_words:
                break
            current_word = random.choice(next_words)
            result.append(current_word)

        return ' '.join(result)
